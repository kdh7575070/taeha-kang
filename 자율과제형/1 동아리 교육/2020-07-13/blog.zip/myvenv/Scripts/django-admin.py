#!c:\users\taeha\desktop\likelion\2020-07-13\blog\myvenv\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
