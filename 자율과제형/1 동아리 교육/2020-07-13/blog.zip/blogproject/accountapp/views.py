from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import auth #권한부여, 로그인여부확인

# Create your views here.
def signup(request):
    if request.method == 'POST':
        if User.objects.filter(username=request.POST['username']).exists():
                return render(request, 'signup.html',{'error': '이미 사용중인 이름입니다.'})
        if request.POST['password1'] == request.POST['password2']:
            user = User.objects.create_user( username = request.POST['username'], password = request.POST['password1'])
            auth.login(request, user)
            return redirect('home')
        else: return render(request, 'signup.html',{'error': '비밀번호가 일치하지 않습니다.'})
    return render(request, 'signup.html')
    
def login(request):
    if request.method == 'POST':
        user = auth.authenticate(request, username = request.POST['username'], password = request.POST['password'])
        #authenticate -> database에 있는 회원이 맞는지 확인
        if user is not None:
            auth.login(request, user)
            return redirect('home')
        else:
            return render(request, 'login.html',{'error': 'username or password is incorrecy.'} )
    return render(request, 'login.html')

    
def logout(request):
    auth.logout(request)
    return redirect('home')
    