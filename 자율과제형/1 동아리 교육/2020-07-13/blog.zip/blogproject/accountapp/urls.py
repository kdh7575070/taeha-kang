from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('signup/', views.signup, name='signup'), #현재디렉토리라서그냥바로 views.
    path('login/', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
]