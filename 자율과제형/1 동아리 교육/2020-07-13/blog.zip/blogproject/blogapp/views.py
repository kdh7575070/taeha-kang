from django.shortcuts import render, get_object_or_404
from .models import Blog
# Create your views here.
def home(request):
    blogs = Blog.objects
    return render(request, 'home.html', {'blogs':blogs})

# detail 페이지로 넘겨줘야하는데 일단 path converter를 통해 blog_id도 같이 받았다
def detail(request, blog_id):
    #특정모델의 특정객체는 get_object_or_404로 받는다
    detail = get_object_or_404(Blog, pk=blog_id)
    #id가 1 이면 1인 객체를 받아오는 것
    return render(request, 'detail.html', {'detail':detail})