from django.contrib import admin
from .models import * #모델스를 다 가져오겠다

# Register your models here.
# 블로그라는 모델을 보여달라고 알려주기
admin.site.register(Blog)
