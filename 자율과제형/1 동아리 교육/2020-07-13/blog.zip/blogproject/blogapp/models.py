from django.db import models

# Create your models here.
 #이 클래스가 장고 model이라는 것을 char형 date형, textfield형 데이터로 받겠다
class Blog(models.Model):
    title = models.CharField(max_length=200)
    pub_date = models.DateTimeField('date published')
    body = models.TextField()
    def __str__(self):
        return self.title
        #객체의 이름을 object1 2 대신 title로 지정해주겠다
    def summary(self):
        return self.body[:100]