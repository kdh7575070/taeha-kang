from django.shortcuts import render,get_object_or_404,redirect
from .models import Blog, Comment, Like
from django.utils import timezone
# Create your views here.
def blog(request):
    blogs = Blog.objects.all()
    return render(request,'blog.html', { 'blogs' : blogs })

# R
def detail(request, blog_id):
    detail = get_object_or_404(Blog, pk=blog_id)
    comments = Comment.objects.all().filter(post=detail) #코멘츠의 모든 객체들중에 필터를 만족하는 객체만 가져온다
    #즉 디테일과 같은 이름의 포스트 만 여기에 담긴다

     #좋아요를 눌렀는지 안눌렀는지 판별해서 메세지띄우는 부분
    user = request.user #현재유저받아옴
    if detail.likes.filter(id=user.id):
        #likes에는 원래 순서쌍이 들어있으므로 detail.likes에는 해당 id의 블로그와 매칭된 순서쌍이 쫙
        #그중에서 현재유저가 포함된 순서쌍을 뽑아냄 -> 이게 있다면 좋아요를 눌른거니까 좋아요 취소메세지를 띄워주야겠지 
        message = "좋아요취소"
    else:
        message = "좋아요"
    #누른 직후의 처리는 맨밑에 새롭게 함수정의할거임
    return render(request ,'detail.html', { 'detail' : detail, 'comments' : comments , 'message' : message } )

def new(request):
    return render(request, 'new.html')

def create(request):
    blog = Blog() # 객체 틀 하나 가져오기
    blog.title = request.GET['title']  # 내용 채우기
    blog.body = request.GET['body'] # 내용 채우기
    blog.pub_date = timezone.datetime.now() # 내용 채우기
    blog.writer = request.user # 내용 채우기
    blog.save() # 객체 저장하기

    # 새로운 글 url 주소로 이동
    return redirect('/blog/' + str(blog.id))

#삭제
def delete(request, blog_id):
    blog = get_object_or_404(Blog, pk=blog_id)
    blog.delete()
    return redirect('/blog/')
#update

def update(request, blog_id):
    blog = get_object_or_404(Blog, pk =blog_id)

    if request.method == "POST":
        blog.title = request.POST['title']
        blog.body = request.POST['body']
        blog.pub_date = timezone.datetime.now()
        blog.save()
        return redirect('/blog/' +str(blog.id))
    else:
        return render(request,'update.html')


#comment

def comment(request, blog_id):
    if request.method == "POST": #Get이 url창에 뜨는 방식이라면 포스트는 안뜨고 전달하는 방식(데이터전송할때주로)
                                 #POST 이프문 처리를 안하면 마음대로 링크 쳐서 접근할수있게되니까 처리해야함 
        comment = Comment() #모델가져와서 - create와 유사하다
        comment.body = request.POST['body']
        comment.pub_date = timezone.datetime.now()
        comment.post=get_object_or_404(Blog, pk=blog_id) #중요 - 어떤 포스트에 달렸는지를 나타내야지
        comment.c_writer = request.user #중요 -누가 달았는지
        comment.save()
        return redirect('/blog/'+str(blog_id))
    else:
        return redirect('/blog/'+str(blog_id)) #포스트방식으로 안올때 예외를 처리하는것

def comment_delete(request, comment_id):
    comment = get_object_or_404(Comment, pk=comment_id)
    comment.delete()
    blog_id = comment.post.id
    # 코멘트를 지웠을 때, 코멘트랑 연결된 id의 블로그 띄워주기 위해서 comment.post.id로부터 blog_id를 끌어와야한다
    return redirect('/blog/'+str(blog_id))

# 좋아요 되있나 안되있나 판별해서 순서쌍 만들고 제거하는 부분
def post_like(request, blog_id):
    #블로그 아이디와 현재유저를 순서쌍으로 한 likes가 생겨야한다.
    blog = get_object_or_404(Blog, pk=blog_id)

    #위와 유사
    user = request.user
    if blog.likes.filter(id=user.id): #likes라는 필드가 유저랑 연결되있으니까 id라는게 manytomanyfield를 통해 매칭된 유저들의 아이디모은 집합이 되는 것이고
                                      #필터를 통해 그중에서 유저아이디랑 겹치는것이 있는지 여부를 확인해서 가져오는 것임
        blog.likes.remove(user) #있으니까 유저를 제거 - 블로그와매칭되서순서쌍제거
    else:
        blog.likes.add(user) #없으니까 유저를 생성 - 블로그와매칭해서순서쌍생성
        #객체를 없애고 만드는 함수 - delete,save 함수를 user에 대해서 편하게 만들어놨다고 보면됨
    return redirect('/blog/'+str(blog_id)) #다시 detail로 보내줘야지
