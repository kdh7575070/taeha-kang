from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Blog(models.Model):
    title = models.CharField(max_length = 200)
    pub_date = models.DateTimeField('data published')
    body = models.TextField()
    #admin권한 부여를 위한 유저와의연결!!
    writer = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    #on_delete 객체가 삭제될때 연결도 같이 삭제된다
    #null=True writer가 비어있어도 괜찮다 - 원래 writer라는 항목이 없는데 새로 추가를 하는 상황을 보자,
    #비어있어도 괜찮아야지 아무런 문제가 없이 writer라는 항목이 생성된다 / False면 migrate 자체가 안됨

    #좋아요내용
    likes=models.ManyToManyField(User, through='Like', through_fields=('blog','user'), related_name='likes')
    #라이크라는 클래스(중개모델)를 통해서 유저와 다대다관계를 형성
    #다대다필드는 쓰루필드( , )정보들이 리스트로 담긴다
    #related name? 쿼리셋을 다 가져오는 이름이 원래는 likes_set인데 그걸 likes로 지정하겠다는 뜻
    
    #그 라이크 개수를 카운트하는함수
    def like_count(self):
        return self.likes.count() #likes하면 리스트를 싹끌고온다 related_name없으면likes_set

    def __str__(self):
        return self.title

class Comment(models.Model):
    body = models.TextField(max_length = 500)
    pub_date = models.DateTimeField('data published')
    #일대다관계를 위해
    c_writer = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    # null=True 필요없다 어짜피 처음 추가하는 거니까
    post = models.ForeignKey(Blog, on_delete=models.CASCADE)
    # 어느 포스트에 해당하는지 - 포스트 정보도 받아와야한다

#라이크의 중개모델
class Like(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True)
    blog = models.ForeignKey(Blog, on_delete=models.CASCADE, null=True)